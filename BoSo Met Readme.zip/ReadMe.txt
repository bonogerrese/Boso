Hi,

This is BoSo, an website where you can enter your music preference and get 'others' their advice by comparing your input to each other.
The website currently is a dummy and records only the data you put in yourself and stores it as an array. this means there is no
user database that gives you unique recommendations. I hope you find a way to do something useful with is as well.

You use it by entering what songs/artists you like and then let some other people do the same and you will get a list that 
will tell you what you should really listen to.

My next step would be to build a database around it so you would truly get others people input back at your input.